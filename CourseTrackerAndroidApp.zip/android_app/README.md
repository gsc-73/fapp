# Course Tracker — Android wrapper app

This is a minimal native Android app that wraps your existing
`tracker.html` (bundled unchanged in `app/src/main/assets/`) in a WebView,
and solves the two problems the browser version couldn't:

1. **Swipe-down-to-minimize now actually works.** A browser tab can never
   see touch gestures that land on a cross-origin iframe (the YouTube
   embed) — that's a hard security boundary, not a bug. In this native app,
   `VideoSwipeContainer.kt` sits *around* the WebView and uses Android's
   `onInterceptTouchEvent` to watch for a real downward drag starting over
   the video, and steals the gesture away before the WebView/iframe ever
   sees it — then calls your existing `enterMiniPlayer()` JS function. Plain
   taps (play/pause, seek, YouTube's own controls) are left completely
   alone and pass through normally.

2. **The "Error 153 / Video player configuration error" is fixed for good.**
   The app serves your HTML over `https://appassets.androidx.net/assets/...`
   (via `WebViewAssetLoader`) instead of `file://` or `content://`, which is
   what YouTube's embed was rejecting before.

Nothing about your existing HTML/CSS/JS had to be rewritten — the same
`tracker.html` still works fine if you just open it in a normal browser or
host it online; the two small bridge hooks it calls
(`AndroidBridge.reportVideoRect` / `reportMiniState`) are wrapped in
try/catch and simply do nothing outside this app.

## Building via GitHub Actions (no Android Studio needed)

This project includes `.github/workflows/build.yml`, which builds the debug
APK automatically in the cloud every time you push. The zip you downloaded
already has a git repo initialized with one commit — you just need to push
it to GitHub:

1. On GitHub, create a **new empty repository** (no README/gitignore/license
   — leave it totally empty), e.g. `course-tracker-app`.
2. Unzip this project locally, then in that folder run:
   ```bash
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```
3. On GitHub, open the **Actions** tab of your new repo — a "Build APK" run
   will already be in progress (it starts automatically on push).
4. When it finishes (a few minutes), click into that run → scroll to
   **Artifacts** → download `course-tracker-debug-apk`. Unzip it and you
   have `app-debug.apk`, ready to install on your phone.

Every time you push a new commit (e.g. after swapping in an updated
`tracker.html`), a fresh APK is built automatically — no local Android SDK,
no Android Studio.

To install the APK on your phone: copy it over, tap it, and allow
"install from unknown sources" if prompted (this is a debug build, not
from the Play Store, so Android will ask once).

## How to build

1. Install **Android Studio** (this project can't be compiled inside this
   sandbox — there's no Android SDK here, only the source).
2. `File → Open`, select the `android_app` folder.
3. Let Gradle sync (first sync downloads Gradle 8.7 + dependencies —
   needs internet).
4. Plug in an Android phone (USB debugging on) or start an emulator.
5. Click **Run ▶**.

## If you update tracker.html later

Just replace `app/src/main/assets/tracker.html` with the new version and
rebuild — nothing else in the Android project needs to change.

## What's intentionally minimal here

This is scoped to solve exactly the swipe/embed problems, not a full
rewrite:
- One Activity, one WebView, no navigation stack beyond what your web app
  already does internally.
- No app icon design (a placeholder blue circle is included so the build
  doesn't fail on a missing resource) — swap
  `app/src/main/res/mipmap-*/ic_launcher.png` for real artwork whenever you
  like.
- No Play Store signing/release config — this is a debug-buildable project;
  ask if you want a release/signing setup later.
