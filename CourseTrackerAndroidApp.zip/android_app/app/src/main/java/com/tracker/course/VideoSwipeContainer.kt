package com.tracker.course

import android.content.Context
import android.graphics.Rect
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.webkit.WebView
import android.widget.FrameLayout
import kotlin.math.abs

/**
 * Wraps the WebView and gives native touch-interception over the area where
 * the video (a cross-origin YouTube iframe) currently sits on screen.
 *
 * A normal browser tab can NEVER see touch/swipe gestures that land on a
 * cross-origin iframe — that's a hard browser security boundary, not a bug
 * in the web app. This container is the actual fix: Android lets a parent
 * ViewGroup watch a touch stream before its children get it
 * (onInterceptTouchEvent), and "steal" it away mid-gesture once it looks
 * like a real drag. We only steal it once the user is clearly dragging
 * down, so ordinary taps (play/pause, seek bar, YouTube's own controls)
 * still pass straight through untouched.
 *
 * The web page tells us, via [reportVideoRect] (called through the
 * `AndroidBridge` JS interface), exactly where the video is on screen right
 * now — since that position moves around as the user scrolls / navigates
 * the app. We only start watching for a minimize-swipe when a touch begins
 * inside that rect.
 */
class VideoSwipeContainer @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : FrameLayout(context, attrs) {

    /** Screen-space rect of the currently visible video, in px. Empty (all
     *  zero) means "no video on screen right now" — e.g. mini player already
     *  active, or the user isn't on the watch page at all. */
    private val videoRect = Rect()
    var isMiniActive = false

    private var webView: WebView? = null

    private val touchSlop = ViewConfiguration.get(context).scaledTouchSlop
    // Extra distance beyond touchSlop required, on top of being mostly
    // vertical, before we commit to stealing the gesture. Keeps a normal
    // tap-to-seek or tap-to-pause on the YouTube controls from ever being
    // swallowed by accident.
    private val dragCommitSlop = touchSlop * 2.5f
    // How far the user has to drag down, once we've committed to the
    // gesture, before we actually trigger minimize on release.
    private var minimizeThresholdPx = 0f

    private var downX = 0f
    private var downY = 0f
    private var touchStartedInVideo = false
    private var dragging = false

    init {
        minimizeThresholdPx = resources.displayMetrics.density * 70f
    }

    fun attachWebView(wv: WebView) {
        webView = wv
    }

    /** Called from the `AndroidBridge` JS interface (see MainActivity) with
     *  the video wrap's current getBoundingClientRect(), in CSS px — which
     *  is the same as device px here since we don't let the WebView zoom. */
    fun reportVideoRect(left: Int, top: Int, width: Int, height: Int) {
        if (width <= 0 || height <= 0) {
            videoRect.setEmpty()
        } else {
            videoRect.set(left, top, left + width, top + height)
        }
    }

    fun reportMiniState(isMini: Boolean) {
        isMiniActive = isMini
        if (isMini) {
            // Once mini, the pill is small and has its own tap targets —
            // native shouldn't be intercepting drags over it at all.
            videoRect.setEmpty()
        }
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.x
                downY = ev.y
                dragging = false
                touchStartedInVideo = !isMiniActive &&
                    !videoRect.isEmpty &&
                    videoRect.contains(ev.x.toInt(), ev.y.toInt())
                // Never intercept on DOWN itself — let it reach the WebView
                // normally so a plain tap (play/pause, seek) still works.
                return false
            }
            MotionEvent.ACTION_MOVE -> {
                if (!touchStartedInVideo || dragging) return dragging
                val dx = ev.x - downX
                val dy = ev.y - downY
                if (dy > dragCommitSlop && abs(dy) > abs(dx) * 1.4f) {
                    dragging = true
                    return true
                }
                return false
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                // If we never committed to a drag, don't consume — let the
                // WebView see the up/cancel normally.
                val was = dragging
                dragging = false
                touchStartedInVideo = false
                return was
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (!dragging) return false
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> return true
            MotionEvent.ACTION_UP -> {
                val dy = ev.y - downY
                dragging = false
                if (dy > minimizeThresholdPx) {
                    webView?.evaluateJavascript("enterMiniPlayer();", null)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                dragging = false
                return true
            }
        }
        return true
    }
}
