package com.tracker.course

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.webkit.WebViewAssetLoader

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var swipeContainer: VideoSwipeContainer

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        swipeContainer = findViewById(R.id.swipeContainer)
        webView = findViewById(R.id.webView)
        swipeContainer.attachWebView(webView)

        // Serves app/src/main/assets/ over a real https:// origin instead of
        // file:// — this is what makes the YouTube embed load reliably
        // (Error 153 is commonly triggered by file:// / content:// origins).
        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            cacheMode = WebSettings.LOAD_DEFAULT
            @Suppress("DEPRECATION")
            databaseEnabled = true
        }

        webView.addJavascriptInterface(AndroidBridge(swipeContainer), "AndroidBridge")

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView,
                request: WebResourceRequest
            ): WebResourceResponse? = assetLoader.shouldInterceptRequest(request.url)
        }

        // Lets fullscreen <video>/YouTube fullscreen requests actually work
        // (needed for the ⤢ landscape button's Fullscreen API call).
        webView.webChromeClient = WebChromeClient()

        webView.loadUrl("https://appassets.androidx.net/assets/tracker.html")
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (swipeContainer.isMiniActive) {
                webView.evaluateJavascript("exitMiniPlayer(); closeVideoModal();", null)
                return true
            }
            if (webView.canGoBack()) {
                webView.goBack()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }
}
