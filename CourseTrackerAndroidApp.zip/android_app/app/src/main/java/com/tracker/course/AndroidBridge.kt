package com.tracker.course

import android.webkit.JavascriptInterface

/**
 * Exposed to the page as `window.AndroidBridge` via
 * WebView.addJavascriptInterface(). The web app already calls these two
 * methods defensively (wrapped in try/catch, only if the object exists) —
 * see notifyAndroidMiniState() and reportVwVideoRectToAndroid() in
 * tracker.html — so the exact same HTML file still works fine as a normal
 * web page with no native wrapper at all.
 */
class AndroidBridge(private val container: VideoSwipeContainer) {

    @JavascriptInterface
    fun reportVideoRect(left: Int, top: Int, width: Int, height: Int) {
        container.post { container.reportVideoRect(left, top, width, height) }
    }

    @JavascriptInterface
    fun reportMiniState(isMini: Boolean) {
        container.post { container.reportMiniState(isMini) }
    }
}
